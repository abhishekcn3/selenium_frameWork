package com.sap.in.signup;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.sap.in.commonlibrary.BaseClass;
import com.sap.in.commonlibrary.ExcelReadAndWrite;
import com.sap.in.signup.page.Home;
import com.sap.in.signup.page.Registration;

public class Signup_TC extends BaseClass {
    WebDriver driver;
    Home home;
    Registration registration;
    public static List<Object> lstData;
    HashMap<String, Object> listClaimJobsData = null;
    String actual="Thank you for registering with SAP Conversational AI";
        
    
    @Test()
    public void TC_01_NewUserSignUp() {
        home = new Home(driver);
        registration = new Registration(driver);
        listClaimJobsData = (HashMap<String, Object>) lstData.get(1);
        home.clickOnSignUp();
        registration.registerNewUser(listClaimJobsData);
        Assert.assertEquals(actual, registration.getSuccessMessage());
    }        
}
