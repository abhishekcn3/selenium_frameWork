package com.sap.in.commonlibrary;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.sap.in.commonlibrary.ExtentManager;
import com.sap.in.commonlibrary.AppConstants;
import com.sap.in.commonlibrary.ExcelReadAndWrite;

public class BaseClass {
    protected static WebDriver driver;
    public static final String RESOURCES_TEST_DATA = ".\\resources\\TestData\\";
    public static String gstrDownloadLocation;
    public static Logger APP_LOGS = Logger.getLogger(BaseClass.class);
    public ExcelReadAndWrite excelReadWrite;
    public static List<Object> lstData;
    public static List<Object> lstSecondaryData;
    public static String applicationUserName;
    public static String excelSheetName;
    public static String testDataFileName;
    public static String userContextForImporter;
    public static String userContextForDealer;
    public static ExtentHtmlReporter extent;
    public static ExtentTest test;
    public static String browserName;
    public static String url;
    public static String testDataEnv;
    public static boolean refreshPageToRemoveErrorIcon = false;
    ExtentManager extentManager = null;
    public WebDriver getDriver() {
        return driver;
    }

    public String getBrowserType() {
        Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
        return cap.getBrowserName();
    }

    protected WebDriver setDriver(String browserName, String appURL) {
        try {
            gstrDownloadLocation = System.getProperty(AppConstants.USER_DIR).replace("\\", "\\\\");
            gstrDownloadLocation = gstrDownloadLocation + AppConstants.RESOURCES_DOWNLOAD_LOCATION;
            if (browserName.equalsIgnoreCase("chrome")) {
                driver = initChromeDriver(appURL);
            }
             else {
                Reporter.log("Invalid browser name");
            }
        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
        }
        return driver;
    }

    protected static WebDriver initChromeDriver(String appURL) {
        WebDriver chromeDriver = null;
        try {
            APP_LOGS.info("Launching google chrome with new profile..");
            System.setProperty("webdriver.chrome.driver", AppConstants.driverPath + "chromedriver.exe");
            Map<String, Object> prefs = new HashMap<String, Object>();
            prefs.put("download.default_directory", System.getProperty(AppConstants.USER_DIR) + AppConstants.RESOURCES_DOWNLOAD_LOCATION);
            prefs.put("credentials_enable_service", false);
            prefs.put("profile.password_manager_enabled", false);
            DesiredCapabilities caps = DesiredCapabilities.chrome();
            ChromeOptions options = new ChromeOptions();
            options.setExperimentalOption("prefs", prefs);
            options.addArguments("--disable-extensions");
            options.addArguments("--dns-prefetch-disable");
            options.addArguments("disable-infobars");
            options.addArguments("--disable-popup-blocking");
            options.addArguments("--start-maximized");
            options.setPageLoadStrategy(PageLoadStrategy.NONE);
            caps.setCapability(ChromeOptions.CAPABILITY, options);
            ChromeDriverService service = ChromeDriverService.createDefaultService();
            WebDriver driver = new ChromeDriver(caps);
            TimeUnit.SECONDS.sleep(1);
            driver.manage().deleteAllCookies();
            driver.navigate().to(appURL);
            chromeDriver = driver;

        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
        }
        return chromeDriver;
    }

    @Parameters({ "browser","appURL",})
    @BeforeSuite(alwaysRun = true)
    public void beforeSuite(@Optional("browser") String browser,String appURL,ITestContext ctx) {
            browserName = browser;
            url = appURL;
            String suiteName = ctx.getCurrentXmlTest().getSuite().getName();
            String extentReportFileName = suiteName+ ".html";
            APP_LOGS.info("******** " + suiteName + " Started **************");
            ExtentHtmlReporter htmlReporter;
    }

    @Parameters({ "browser", "appURL","sheetName", "testDataFileName",})
    @BeforeClass(alwaysRun = true)
    public void initializeTestBaseSetup(String browserType, String appURL, String sheetName, String testDataFile) throws IOException {
        String browserName = browserType;
        String URL = appURL;
        driver = setDriver(browserName, URL);
        excelSheetName = sheetName;
        excelReadWrite = new ExcelReadAndWrite(RESOURCES_TEST_DATA + "\\" +testDataFileName, sheetName);
        lstData = excelReadWrite.readAll();
    } 

    @BeforeMethod(alwaysRun = true)
    public void executeTestCase(Method method) {
        try {
            APP_LOGS.info(" *********** " + method.getName() + " *********** ");
        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
        }
    }

    @AfterMethod(alwaysRun = true)
    public void logOutFromApplicationsAndQuitBrowser() {
        try {
            //extent.endTest(test);
            extent.flush();
            driver.quit();
       } catch (Exception e) {

          APP_LOGS.error(e.getMessage());
       }
    }

    @AfterSuite(alwaysRun = true)
    protected void afterSuite(ITestContext ctx) {
        APP_LOGS.info("******** " + ctx.getCurrentXmlTest().getSuite().getName() + " Ended *************");
    }

    
    }

