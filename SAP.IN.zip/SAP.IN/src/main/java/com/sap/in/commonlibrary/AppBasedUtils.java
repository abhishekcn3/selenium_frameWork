package com.sap.in.commonlibrary;

import java.io.File;
import java.util.HashMap;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.testng.Assert;

import com.sap.in.commonlibrary.AppBasedUtils;
import com.sap.in.commonlibrary.UIUtils;

public class AppBasedUtils {
    public static Logger APP_LOGS = Logger.getLogger(AppBasedUtils.class);
    UIUtils keywords = new UIUtils();
    /**
     * A utility to clear Screenshot folder
     */
    public static void clearScreeshotFolder() {
        String screenShotFolder;
        try {
            screenShotFolder = System.getProperty("user.dir") + ".\\resources\\Screenshot\\";
            File clearScreenShotCaptured = new File(screenShotFolder);
            FileUtils.cleanDirectory(clearScreenShotCaptured);
        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
            APP_LOGS.info("Screenshot folder is not cleared");
            Assert.fail("Screenshot folder is not cleared");
        }
    }
    
    public String getStringData(HashMap<String, Object> testDataHolder, String key) {
        String testDataStr = null;
        try {
            if ((testDataHolder.get(key) != null)) {
                testDataStr = testDataHolder.get(key).toString();
            } else {
                keywords.APP_LOGS.info("Error occurred while reading test data.");
            }
            return testDataStr;
        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
            Assert.fail("Error occurred while reading test data.");
        }
        return testDataStr;
}}
