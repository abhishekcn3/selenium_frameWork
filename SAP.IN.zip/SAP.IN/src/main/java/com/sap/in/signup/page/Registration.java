package com.sap.in.signup.page;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.apache.xpath.compiler.Keywords;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import com.sap.in.commonlibrary.UIUtils;
import com.sap.in.commonlibrary.AppBasedUtils;

public class Registration {
    public Logger APP_LOGS = Logger.getLogger(Registration.class);
    WebDriver driver;
    AppBasedUtils appBasedUtils = new AppBasedUtils();
    UIUtils keywords = new UIUtils(driver);
    SoftAssert softAssert = new SoftAssert();

    @FindBy(how = How.ID, using = "firstName")
    WebElement firstNameElement;
    
    @FindBy(how = How.ID, using = "lastName")
    WebElement lastNameElement;
    
    @FindBy(how = How.ID, using = "mail")
    WebElement emailElement;
    
    @FindBy(how = How.ID, using = "newPasswordInput")
    WebElement passwordElement;
    
    @FindBy(how = How.ID, using = "retypeNewPasswordInput")
    WebElement reTypepasswordElement;

    @FindBy(id="pdAccept")
    private WebElement pdAccept;
    
    @FindBy(id="touAccept")
    private WebElement touAccept;
    
    @FindBy(xpath="//button[@id='sapStoreRegisterFormSubmit']")
    private WebElement rigisterButton;
    
    @FindBy(xpath="//div[contains(text(),'Sign up')]")
    private WebElement signUp;
    
    @FindBy(xpath="//button[@id='sapStoreRegisterFormSubmit']")
    private WebElement ok;
    
    @FindBy(xpath="//h1[@class='ids-heading-1']")
    private WebElement thanksText;
    
    public Registration(WebDriver driver) {
        this.driver = driver;
        // This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }
    
    public void registerNewUser(HashMap<String, Object> Data) {
        try {
            keywords.input(firstNameElement, appBasedUtils.getStringData(Data, "FirstName"), "First Name");
            keywords.input(firstNameElement, appBasedUtils.getStringData(Data, "LasttName"), "Last Name");
            keywords.input(firstNameElement, appBasedUtils.getStringData(Data, "Email"), "Mail");
            keywords.input(firstNameElement, appBasedUtils.getStringData(Data, "Password"), "Password");
            keywords.input(firstNameElement, appBasedUtils.getStringData(Data, "RePassword"), "RPassword");
            keywords.setCheckboxIfNotSelected(pdAccept);
            keywords.setCheckboxIfNotSelected(touAccept);
            keywords.clickOnButton(driver, rigisterButton);
        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
        }
    }
    
    public String getSuccessMessage()
    {
        String ExpectedText = thanksText.getText();
        return ExpectedText; 
    }
}
