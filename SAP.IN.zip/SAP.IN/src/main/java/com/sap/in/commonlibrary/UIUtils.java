package com.sap.in.commonlibrary;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;

public class UIUtils {
    WebDriver driver;
    public Logger APP_LOGS = Logger.getLogger(UIUtils.class);
    BaseClass baseClass = new BaseClass();
    public UIUtils(WebDriver driver) {
        this.driver = driver;
        PropertyConfigurator.configure("log4j.properties");
    }

    public UIUtils() {
    }

    public String screenshot(String strFileName, WebDriver driver) {
        String fnameWithTimeStamp = new String();
        try {
            String timeStamp = new SimpleDateFormat("yyyy-MM-dd_hh-mm-ss").format(new Date());
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            fnameWithTimeStamp = System.getProperty("user.dir") + ".\\resources\\Screenshot\\" + strFileName + timeStamp + ".jpg";
            File screnshotCaptured = new File(fnameWithTimeStamp);
            FileUtils.copyFile(scrFile, screnshotCaptured);
            APP_LOGS.info("Screenshot is captured for failed testcase. File name is:" + screnshotCaptured.getAbsolutePath());
        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
            APP_LOGS.info("Screenshot has not captured");
            Assert.fail("Screenshot has not captured");
        }
        return fnameWithTimeStamp;
    }

    public String screenshotExtentReport(WebDriver driver, String strFileName) {
        String fnameWithTimeStamp = new String();
        try {
            String timeStamp = new SimpleDateFormat("yyyy-MM-dd_hh-mm-ss").format(new Date());
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            fnameWithTimeStamp = System.getProperty("user.dir") + ".\\resources\\Screenshot\\" + strFileName + timeStamp + ".jpg";
            File screnshotCaptured = new File(fnameWithTimeStamp);
            FileUtils.copyFile(scrFile, screnshotCaptured);
            APP_LOGS.info("Screenshot is captured for failed testcase. File name is:" + screnshotCaptured.getAbsolutePath());
        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
            APP_LOGS.info("Screenshot has not captured");
            Assert.fail("Element not found Exception");
        }
        return fnameWithTimeStamp;

    }

    public void input(WebElement inputBox, Object obj, String fieldName) {
        try {
            String strText = obj.toString().trim();
            inputBox.clear();
            inputBox.sendKeys(strText);
            APP_LOGS.info(" Value '" + inputBox.getAttribute("value") + "' is set to \"" + fieldName + "\" text field");
        } catch (NoSuchElementException e) {
            APP_LOGS.info(inputBox.getAttribute("id") + "  element not found");
            Assert.fail(inputBox.getAttribute("id") + "  element not found");
        }
    }
    
    public boolean waitForVisibilityOfElement(WebDriver driver1, int intTimeToWait, WebElement elementToVisible) {
        try {
            new WebDriverWait(driver1, intTimeToWait).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOf(elementToVisible));
            return true;
        } catch (Exception e) {
            APP_LOGS.error(e);
            APP_LOGS.error(e.getMessage());
            Assert.fail("Element not found within " + intTimeToWait + " seconds");
        }
        return false;
    }
   
    public void waitTime(int intTimeToWait) {
        try {
            Thread.sleep(intTimeToWait);
        } catch (InterruptedException e) {
            Assert.fail("Element not found within " + intTimeToWait + " seconds");
        }
    }
    
    public void setCheckboxIfNotSelected(WebElement element) {
        try {
            if (!element.isSelected()) {
                element.click();
            }
        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
        }
    }

    public void clickOnButton(WebDriver driver, WebElement btn) {
        try {
            //JavascriptExecutor jse = (JavascriptExecutor) driver;
         //   jse.executeScript("arguments[0].click();", btn);
           btn.click();
            APP_LOGS.info("Clicked on button");
        } catch (NoSuchElementException e) {
            APP_LOGS.info(btn + "  element not found");
            Assert.fail(btn + "  element not found");
        } catch (Exception e) {
            APP_LOGS.info(btn + " element not found");
            Assert.fail(btn + "  element not found");
        }
    }

}
