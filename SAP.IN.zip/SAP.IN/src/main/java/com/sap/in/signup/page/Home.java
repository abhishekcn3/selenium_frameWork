package com.sap.in.signup.page;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import com.sap.in.commonlibrary.UIUtils;

public class Home {

    public Logger APP_LOGS = Logger.getLogger(Home.class);
    WebDriver driver;
    UIUtils keywords = new UIUtils(driver);
    SoftAssert softAssert = new SoftAssert();

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Sign up')]")
    WebElement signUpElement;

    public Home(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void clickOnSignUp() {
        try {
            driver.switchTo().defaultContent();
            keywords.clickOnButton(driver, signUpElement);
        } catch (Exception e) {
            APP_LOGS.error(e.getMessage());
        }
    }
}
